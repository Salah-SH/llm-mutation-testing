# Solidity API

## IUniswapV2Sync

### sync

```solidity
function sync() external
```

