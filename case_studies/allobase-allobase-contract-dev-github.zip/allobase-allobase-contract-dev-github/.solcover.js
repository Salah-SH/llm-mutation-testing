module.exports = {
  skipFiles: ['mocks']
};